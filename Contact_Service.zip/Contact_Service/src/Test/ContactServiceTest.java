package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ContactService.Contact;
import ContactService.ContactService;

class ContactServiceTest {
	private ContactService contactService;
	
	@BeforeEach
	public void setup() {
		contactService = new ContactService();
		
	}


	@Test
	public void testAddContact() {
		//New contact
		Contact contact = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		//Adding contact
		assertTrue(contactService.addContact(contact));
		assertEquals(contact, contactService.getContact("12345"));
	}
	
	@Test
	public void testAddContactDupID() {
		//FirstID
		Contact contact1 = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		//DuplicateID
		Contact contact2 = new Contact("12345", "James", "Bond", "8180828193", "111 Second St.");
		//FirstID
		assertTrue(contactService.addContact(contact1));
		//DuplicateID
		assertNull(contactService.addContact(contact2));
	}
	
	@Test
	public void testDeleteContact() {
		Contact contact = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		contactService.addContact(contact);
		assertTrue(contactService.deleteContact("12345"));
		assertNull(contactService.getContact("12345"));
		}
	
	@Test
	public void testUpdateContact() {
		Contact contact = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		contactService.addContact(contact);
		assertTrue(contactService.updateContact("12345", "James", "Bond", "8180828193", "111 Second St."));
		
		Contact updatedContact = contactService.getContact("12345");
		assertEquals("James", updatedContact.getFirstName());
		assertEquals("Bond", updatedContact.getLastName());
		assertEquals("8180828193", updatedContact.getNumber());
		assertEquals("111 Second St.", updatedContact.getAddress());
		
		
	}
}