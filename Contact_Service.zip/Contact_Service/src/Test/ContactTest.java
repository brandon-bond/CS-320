//Brandon Bond
//SNHU
//CS-320
//11/18/2024

package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ContactService.Contact;

class ContactTest {

	@Test
	public void testNewContact() {
		Contact contact = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		assertEquals("12345", contact.getContactID());
		assertEquals("Brandon", contact.getFirstName());
		assertEquals("Bond", contact.getLastName());
		assertEquals("1800800800", contact.getNumber());
		assertEquals("111 First St.", contact.getAddress());
		
	}
	
	@Test
	public void testNewContactInvalid() {
		assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Brandon", "Bond", "1800800800", "111 First St."));
		assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Brandon", "Bond", "1800800800", "111 First St."));
	}
	
	@Test
	public void testSetters() {
		Contact contact = new Contact("12345", "Brandon", "Bond", "1800800800", "111 First St.");
		contact.setFirstName("James");
		contact.setLastName("Bond");
		contact.setNumber("8180828193");
		contact.setAddress("111 Second St.");
		
		assertEquals("Brandon", contact.getFirstName());
		assertEquals("Bond", contact.getLastName());
		assertEquals("8180828193", contact.getNumber());
		assertEquals("8111 Second St.", contact.getAddress());
		
	}
}
