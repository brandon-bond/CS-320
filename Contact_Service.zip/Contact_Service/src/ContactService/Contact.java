//Brandon Bond
//SNHU
//CS-320
//11/17/2024

package ContactService;

public class Contact {
	
	//Strings
	private String contactID;
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	
	//Setting rules for the strings
	public Contact(String contactID, String firstName, String lastName, String Number, String Address) {
		if (contactID == null || contactID.length() > 10) throw new IllegalArgumentException("Invalid contactID");
		if (firstName == null || firstName.length() > 10) throw new IllegalArgumentException("Inavalid First Name");
		if (lastName == null || lastName.length() > 10) throw new IllegalArgumentException("Invalid Last Name");
		if (Number == null || Number.length() > 10) throw new IllegalArgumentException("Invalid Phone Number");
		if (Address == null || Address.length() > 30) throw new IllegalArgumentException("Invalid Address");
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
		this.Address = Address;
	}
	
	//Getter for inputs
	public String getContactID() { 
		return contactID; 
		}
	public String getFirstName() { 
		return firstName; 
		}
	public String getLastName() { 
		return lastName; 
		}
	public String getNumber() { 
		return Number; 
		}
	public String getAddress() { 
		return Address; 
		}
	
	//Setters for the system from inputs
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) throw new IllegalArgumentException("Inavalid First Name");
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) throw new IllegalArgumentException("Inavalid Last Name");
		this.lastName = lastName;
	}
		
	public void setNumber(String Number) {
		if (Number == null || Number.length() > 10) throw new IllegalArgumentException("Inavalid Phone Number");
		this.Number = Number;
	}
	
	public void setAddress(String Address) {
		if (Address == null || Address.length() > 30) throw new IllegalArgumentException("Inavalid Address");
		this.Address = Address;
	}
	
}
