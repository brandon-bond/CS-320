//Brandon Bond
//SNHU
//CS-320
//11/17/2024

package ContactService;

import java.util.HashMap;

public class ContactService {
	private HashMap <String, Contact> contacts = new HashMap<>();
	
	//Adding a new contact
	public boolean addContact(Contact contact) {
		//Existing contact exception
		if (contacts.containsKey(contact.getContactID())) {
			return false;
		}
		//New contact ID
		contacts.put(contact.getContactID(), contact);
		return true;
		
	}
	
	//Deleting an existing contact
	public boolean deleteContact(String contactID) {
		//No existing contact exception
		if (!contacts.containsKey(contactID)) {
			return false;
		}
		//Contact exists remove
		contacts.remove(contactID);
		return true;
	}
	
	//Updating a contact
	public boolean updateContact(String contactID, String firstName, String lastName, String Number, String Address) {
		Contact contact = contacts.get(contactID);
		//No existing contact
		if (contact == null) return false;
		
		//Changing an existing contact
		if (firstName != null && firstName.length() <= 10) contact.setFirstName(firstName);
		if (lastName != null && lastName.length() <= 10) contact.setLastName(lastName);
		if (Number != null && Number.length() == 10) contact.setNumber(Number);
		if (Address != null && Address.length() <= 30) contact.setAddress(Address);
		
		return true;
	}
	
	//Adding getContact for Testing
	public Contact getContact(String contactID) {
		return contacts.get(contactID);
	}
}